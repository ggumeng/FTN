#pragma once
class CMath {
	int a, b;
public:
	CMath(int _a, int _b);
	int Add();
};